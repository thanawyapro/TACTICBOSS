const json = (status, body) => ({ statusCode: status, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify(body) });

const L = (lang, ar, en, es, fr) => {
  if (lang === 'ar') return ar;
  if (lang === 'es') return es || en;
  if (lang === 'fr') return fr || en;
  return en;
};

const fallbackTips = (lang = 'ar', body = {}) => {
  const formation = body.formation || '4-2-3-1';
  const game = String(body.game || body.gameId || '');
  const note = String(body.userNote || '').toLowerCase();
  const tips = [];
  if (/طرف|جناح|wide|wing|flank|banda|aile|côté/.test(note)) {
    tips.push(L(lang,
      'ملاحظتك عن الأطراف: فعّل التعليمة الدفاعية على جهة الخطر فقط، ولا تستخدم Counter Target إلا على جناح واحد سريع.',
      'Wide danger note: apply the defensive instruction only on the threatened side, and use Counter Target on one fast winger only.',
      'Peligro por banda: usa la instrucción defensiva solo en el lado amenazado y Counter Target en un solo extremo rápido.',
      'Danger sur le côté : appliquez la consigne défensive uniquement côté danger et Counter Target sur un seul ailier rapide.'
    ));
  }
  if (/ضغط|press|pressing|presión|pression/.test(note)) {
    tips.push(L(lang,
      'ملاحظتك عن الضغط: لا تزود التعليمات؛ اختَر مخرج تمرير مباشر، وفي PES استخدم Counter Target فقط لو عندك مهاجم يستلم.',
      'Pressure note: do not add many instructions; use a direct outlet, and in PES use Counter Target only if you have a receiving forward.',
      'Nota de presión: no añadas muchas instrucciones; usa una salida directa y en PES usa Counter Target solo con un delantero receptor.',
      'Note pressing : n’ajoutez pas trop de consignes ; utilisez une sortie directe, et dans PES Counter Target seulement avec un attaquant relais.'
    ));
  }
  if (/سرع|سريع|pace|fast|rápido|vitesse|rapide/.test(note)) {
    tips.push(L(lang,
      'ملاحظتك عن السرعة: لا ترفع خط الدفاع، وفي eFootball اجعل Deep Line على DMF فقط لحماية العمق.',
      'Pace note: do not raise the line; in eFootball use Deep Line on DMF only to protect depth.',
      'Rival rápido: no subas la línea; en eFootball usa Deep Line solo en el MCD para proteger la profundidad.',
      'Adversaire rapide : ne montez pas la ligne ; dans eFootball utilisez Deep Line sur le MDF seulement.'
    ));
  }
  if (/amf|صانع|playmaker|10|mediapunta|créateur/.test(note)) {
    tips.push(L(lang,
      'لو الخطر من صانع اللعب: استخدم Man Marking أو Tight Marking على AMF/SS حسب اللعبة، ولا تسحب قلبي الدفاع للمراقبة.',
      'If danger is the playmaker: use Man Marking/Tight Marking on AMF/SS where supported; do not pull CBs out.',
      'Si el peligro es el mediapunta: usa Man Marking/Tight Marking sobre AMF/SS si el juego lo permite; no saques a los centrales.',
      'Si le danger vient du créateur : utilisez Man Marking/Tight Marking sur AMF/SS si disponible ; ne sortez pas les DC.'
    ));
  }
  const generic = [
    L(lang,
      `ابدأ بـ ${formation} كما هي، ولا تغيّر أكثر من تعليماتين قبل الدقيقة 30.`,
      `Start with ${formation}; do not change more than two instructions before minute 30.`,
      `Empieza con ${formation}; no cambies más de dos instrucciones antes del minuto 30.`,
      `Commencez avec ${formation}; ne changez pas plus de deux consignes avant la 30e minute.`),
    L(lang,
      game.includes('PES') ? 'في PES استخدم فقط Advanced Instructions الموجودة داخل Game Plan، ولا تعرض Player Styles كأنها تعليمات.' : 'التزم بتعليمات اللعبة المتاحة فقط، ولا تخلط بين PES و eFootball و EA FC.',
      game.includes('PES') ? 'In PES, use only Advanced Instructions from Game Plan; do not present Player Styles as instructions.' : 'Use only instructions available in the selected game; do not mix PES, eFootball and EA FC.',
      game.includes('PES') ? 'En PES, usa solo Advanced Instructions de Game Plan; no presentes Player Styles como instrucciones.' : 'Usa solo instrucciones disponibles en el juego elegido; no mezcles PES, eFootball y EA FC.',
      game.includes('PES') ? 'Dans PES, utilisez seulement les Advanced Instructions du Game Plan ; ne présentez pas les Player Styles comme consignes.' : 'Utilisez seulement les consignes disponibles dans le jeu choisi ; ne mélangez pas PES, eFootball et EA FC.'),
    L(lang,
      body.mode === 'counter' ? 'راقب جهة هجوم الخصم أول 10 دقائق، ثم فعّل التعليمات الدفاعية المناسبة فقط.' : 'لو الخطة لا تخلق فرصًا، غيّر منطقة الهجوم قبل تغيير التشكيلة.',
      body.mode === 'counter' ? 'Watch the rival attack side for 10 minutes, then apply only the matching defensive instruction.' : 'If chances are weak, change attack area before changing shape.',
      body.mode === 'counter' ? 'Observa el lado de ataque rival durante 10 minutos y aplica solo la instrucción defensiva adecuada.' : 'Si no creas ocasiones, cambia la zona de ataque antes de cambiar la formación.',
      body.mode === 'counter' ? 'Observez le côté d’attaque adverse pendant 10 minutes, puis appliquez seulement la consigne défensive adaptée.' : 'Si vous créez peu d’occasions, changez la zone d’attaque avant le système.')
  ];
  return [...tips, ...generic].slice(0, 5);
};

export async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return json(200, { ok: true });
  if (event.httpMethod !== 'POST') return json(405, { error: 'Method not allowed' });
  let body = {};
  try { body = JSON.parse(event.body || '{}'); } catch { return json(400, { error: 'Invalid JSON' }); }
  const apiKey = process.env.GEMINI_API_KEY || process.env.OPENAI_API_KEY;
  if (!apiKey) return json(200, { provider: 'local-fallback', tips: fallbackTips(body.lang, body) });

  const langName = body.lang === 'ar' ? 'Arabic' : body.lang === 'es' ? 'Spanish' : body.lang === 'fr' ? 'French' : 'English';
  const system = `You are Tactic Boss AI Coach. Return ONLY JSON: {"tips":["...","...","..."]}. Write ALL tips in ${langName} only. Each tip must directly respond to the user note first, be short and actionable, and must NOT invent settings outside the selected football game. If PES, only mention PES Game Plan or Advanced Instructions. If eFootball, only mention Team Playstyle/Individual Instructions. If EA FC, only mention FC IQ/Player Roles/Team Tactics.`;
  const user = `Lang: ${body.lang || 'ar'}\nMode: ${body.mode}\nGame: ${body.game}\nFormation: ${body.formation}\nStyle: ${body.style}\nOpponent: ${body.opponentFormation} ${body.opponentStyle}\nMatch state: ${body.matchState}\nUser note: ${body.userNote || ''}\nGive 3-5 tips.`;

  try {
    if (process.env.GEMINI_API_KEY) {
      const geminiModel = process.env.GEMINI_MODEL || 'gemini-3.5-flash';
      const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${geminiModel}:generateContent?key=${process.env.GEMINI_API_KEY}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: `${system}\n\n${user}` }] }], generationConfig: { temperature: 0.35, maxOutputTokens: 500, responseMimeType: 'application/json' } })
      });
      const data = await res.json();
      const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || '{}';
      const parsed = JSON.parse(text);
      return json(200, { provider: 'gemini', tips: Array.isArray(parsed.tips) ? parsed.tips.slice(0,5) : fallbackTips(body.lang, body) });
    }
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
      body: JSON.stringify({ model: 'gpt-4.1-mini', messages: [{ role: 'system', content: system }, { role: 'user', content: user }], temperature: 0.35, response_format: { type: 'json_object' } })
    });
    const data = await res.json();
    const parsed = JSON.parse(data?.choices?.[0]?.message?.content || '{}');
    return json(200, { provider: 'openai', tips: Array.isArray(parsed.tips) ? parsed.tips.slice(0,5) : fallbackTips(body.lang, body) });
  } catch (error) {
    return json(200, { provider: 'local-fallback', tips: fallbackTips(body.lang, body), warning: String(error?.message || error) });
  }
}
