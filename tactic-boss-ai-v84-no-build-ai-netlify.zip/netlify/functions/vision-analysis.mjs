const MAX_IMAGE_CHARS = 8_000_000;

const json = (status, body) => ({
  statusCode: status,
  headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
  body: JSON.stringify(body)
});

function parseDataUrl(dataUrl = '') {
  const match = String(dataUrl).match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
  if (!match) return null;
  return { mimeType: match[1], base64: match[2] };
}

function compact(value) {
  return JSON.stringify(value, null, 2).slice(0, 4000);
}

function promptFor(kind, payload) {
  const langInstruction = payload.lang === 'ar'
    ? 'اكتب كل النصوص بالعربية الواضحة المختصرة.'
    : 'Write concise clear English.';
  if (kind === 'match') {
    return `${langInstruction}\nYou are a football gaming tactical analyst for PES/eFootball/EA FC. Analyze the uploaded match screenshot together with the user-entered context. Do not invent unreadable text from the image. If the image is unclear, rely on context and say what is inferred. Return JSON only with these keys: tacticalVerdict, keyBattle, scoreReading, teamReport array, opponentReport array, diagnosis array, mistakes array, weakAreas array, recommendations array, training array, counterStrategy, recommendedFormation, coachScore number 1-100, attackScore number 1-100, defenseScore number 1-100, balanceScore number 1-100, riskLevel, beforeScore number, afterScore number, nextMatchSetup array.\nContext:\n${compact(payload.context)}`;
  }
  return `${langInstruction}\nYou are a football gaming screenshot analyst. Analyze the uploaded image for formation, tactical style, strong zones, weak zones, danger zones, and a generator autofill suggestion. Do not invent unreadable text. Return JSON only with keys: detectedFormation, detectedPlaystyle, confidence number 1-100, strongZones array, weakZones array, dangerZones array, generatorAutofill object with myFormation, oppFormation, myStyle, opponentStyle, notes.\nScreenshot mode: ${payload.mode || 'opponent'}`;
}

async function callGemini({ prompt, image }) {
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw new Error('Missing GEMINI_API_KEY');
  const model = process.env.GEMINI_MODEL || 'gemini-3.5-flash';
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ role: 'user', parts: [{ text: prompt }, { inline_data: { mime_type: image.mimeType, data: image.base64 } }] }],
      generationConfig: { responseMimeType: 'application/json', temperature: 0.2 }
    })
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.error?.message || `Gemini ${res.status}`);
  const text = data?.candidates?.[0]?.content?.parts?.map((p) => p.text || '').join('') || '';
  return JSON.parse(text.replace(/^```json\s*/i, '').replace(/```$/i, '').trim());
}

async function callOpenAI({ prompt, dataUrl }) {
  const key = process.env.OPENAI_API_KEY;
  if (!key) throw new Error('Missing OPENAI_API_KEY');
  const model = process.env.OPENAI_MODEL || 'gpt-4.1-mini';
  const res = await fetch('https://api.openai.com/v1/responses', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model,
      input: [{ role: 'user', content: [{ type: 'input_text', text: prompt }, { type: 'input_image', image_url: dataUrl }] }],
      temperature: 0.2
    })
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.error?.message || `OpenAI ${res.status}`);
  const text = data?.output_text || data?.output?.flatMap((o) => o.content || []).map((c) => c.text || '').join('') || '';
  const cleaned = text.replace(/^```json\s*/i, '').replace(/```$/i, '').trim();
  return JSON.parse(cleaned);
}

export async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return json(200, { ok: true });
  if (event.httpMethod !== 'POST') return json(405, { error: 'Method not allowed' });
  try {
    const payload = JSON.parse(event.body || '{}');
    const image = parseDataUrl(payload.fileDataUrl);
    if (!image) return json(400, { error: 'Invalid image data URL' });
    if (image.base64.length > MAX_IMAGE_CHARS) return json(413, { error: 'Image too large' });
    const prompt = promptFor(payload.kind, payload);
    let result;
    if (process.env.GEMINI_API_KEY) result = await callGemini({ prompt, image });
    else if (process.env.OPENAI_API_KEY) result = await callOpenAI({ prompt, dataUrl: payload.fileDataUrl });
    else return json(501, { error: 'No vision provider configured. Add GEMINI_API_KEY or OPENAI_API_KEY.' });
    return json(200, { ok: true, provider: process.env.GEMINI_API_KEY ? 'gemini' : 'openai', result });
  } catch (error) {
    return json(500, { error: error?.message || 'Vision analysis failed' });
  }
}
